﻿using Microsoft.Extensions.DependencyInjection;
using NLog;
using System;
using System.Configuration;
using System.Threading.Tasks;

namespace GOS
{
    class Program
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private static readonly bool IsLoggingEnabled =
            bool.TryParse(ConfigurationManager.AppSettings["EnableLogging"], out var enabled) && enabled;

        [STAThread]
        static async Task Main(string[] args)
        {
            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
            {
                if (IsLoggingEnabled)
                    Logger.Error(e.ExceptionObject as Exception, "Unhandled exception occurred.");
                Console.WriteLine("A fatal error occurred. See log for details.");
            };

            try
            {
                var serviceCollection = new ServiceCollection();
                DependencyRegister.Instance.RegisterServices(serviceCollection);
                var serviceProvider = serviceCollection.BuildServiceProvider();
               
                var startup = ActivatorUtilities.CreateInstance<Startup>(serviceProvider, serviceProvider);
                await startup.RunAsync();
            }
            catch (Exception ex)
            {
                if (IsLoggingEnabled)
                    Logger.Error(ex, "Exception caught in Main.");
                Console.WriteLine("An error occurred. See log for details.");
            }
            finally
            {
                if (IsLoggingEnabled)
                    LogManager.Shutdown();
            }
        }
    }
}