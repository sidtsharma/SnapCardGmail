﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOS
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter number of packs (N): ");
            int numPacks = 0;

            while (true)
            {
                //Console.Write("\n Enter any number between 1 to " + int.MaxValue);
                if (int.TryParse(Console.ReadLine(), out numPacks) && numPacks >= 1 && numPacks <= int.MaxValue)
                    break;

                Console.Write($"\n Only non negative number is allowed");
            }


            Console.WriteLine("Select matching condition: ");
            Console.WriteLine("1. Face value\n2. Suit\n3. Both");
            int matchType;
            while (true)
            {
                Console.Write("Enter 1, 2 or 3: ");
                if (int.TryParse(Console.ReadLine(), out matchType) && matchType >= 1 && matchType <= 3)
                    break;
            }

            List<string> players = new List<string>();

            for (int i = 1; i <= 2; i++)
            {
                Console.Write($"Please enter player {i} name : ");
                players.Add(Console.ReadLine());
            }

            Game snapGame = new Game(players, numPacks, matchType);
            snapGame.StartGame();
            Console.ReadKey();
        }
    }
}
