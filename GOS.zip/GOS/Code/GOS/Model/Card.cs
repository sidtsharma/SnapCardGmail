﻿
namespace GOS
{
    public class Card
    {
        public Rank Rank { get; set; }
        public Suit Suit { get; set; }
        public Card(Rank r, Suit s) { Rank = r; Suit = s; }
        public override string ToString() => $"{Rank} of {Suit}";
        public bool FaceMatch(Card other) => Rank == other.Rank;
        public bool SuitMatch(Card other) => Suit == other.Suit;
        public bool FullMatch(Card other) => FaceMatch(other) && SuitMatch(other);
    }
}
