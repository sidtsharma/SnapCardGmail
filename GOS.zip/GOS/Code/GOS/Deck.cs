﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static GOS.Constants;

namespace GOS
{
    public class Deck
    {
        private List<Card> cards;

        public Deck(int numberOfDeck)
        {
            cards = new List<Card>();
            InitializeDeck(numberOfDeck);
        }

        private void InitializeDeck(int numberOfDeck)
        {
            cards.Clear();
            for (int pack = 0; pack < numberOfDeck; pack++)
            {
                foreach (Suit suit in Enum.GetValues(typeof(Suit)))
                {
                    foreach (Rank rank in Enum.GetValues(typeof(Rank)))
                    {
                        cards.Add(new Card(rank, suit));
                    }
                }
            }
        }

        public void Shuffle()
        {
            Random random = new Random();
            cards = cards.OrderBy(c => random.Next()).ToList();
        }

        public Card DealCard()
        {
            if (cards.Count == 0)
            {
                return null;
            }
            Card dealtCard = cards[0];
            cards.RemoveAt(0);
            return dealtCard;
        }

        public int CardsLeft()
        {
            return cards.Count;
        }        
    }
}
