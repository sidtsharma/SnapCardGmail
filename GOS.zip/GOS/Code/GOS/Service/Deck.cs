﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static GOS.Constants;

namespace GOS
{
    public class Deck : IDeck
    {
        private List<Card> cards;
        private readonly int _numberOfDecks;

        public Deck(int numberOfDecks)
        {
            cards = new List<Card>();
            _numberOfDecks = numberOfDecks;           
        }       

        public Task InitializeDeckAsync(int numberOfDeck)
        {
            return Task.Run(() =>
            {
                cards.Clear();
                List<Card> tempCards = new List<Card>(numberOfDeck * 52);

                Parallel.For(0, numberOfDeck, pack =>
                {
                    foreach (Suit suit in Enum.GetValues(typeof(Suit)))
                    {
                        foreach (Rank rank in Enum.GetValues(typeof(Rank)))
                        {
                            lock (tempCards)
                            {
                                tempCards.Add(new Card(rank, suit));
                            }
                        }
                    }
                });

                lock (cards) { cards.AddRange(tempCards); } 
               
            });
        }

        public void Shuffle()
        {
            Random random = new Random();
            for (int i = cards.Count - 1; i > 0; i--)
            {
                int j = random.Next(i + 1);
                (cards[j], cards[i]) = (cards[i], cards[j]);
            }
        }

        public async Task ShuffleAsync()
        {
            await Task.Run(() => Shuffle());
        }

        public Card DealCard()
        {
            if (cards.Count == 0)
                return null;
            int lastIndex = cards.Count - 1;
            Card dealtCard = cards[lastIndex];
            cards.RemoveAt(lastIndex);
            return dealtCard;
        }

        public int CardsLeft()
        {
            return cards.Count;
        }  
    }
}
