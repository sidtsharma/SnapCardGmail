using System.Collections.Generic;

namespace GOS
{
    public interface IPlayer
    {
        string Name { get; set; }
        List<Card> Hand { get; }
        void AddCards(List<Card> cardsToAdd);
        Card PlayCard();
    }
}