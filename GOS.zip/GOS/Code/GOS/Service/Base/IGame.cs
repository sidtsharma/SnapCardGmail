using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace GOS
{
    public interface IGame
    {
        Task StartGameAsync(CancellationToken cancellation = default);
    }
}