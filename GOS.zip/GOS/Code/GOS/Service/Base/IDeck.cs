using System.Threading.Tasks;

namespace GOS
{
    public interface IDeck
    {
        Task ShuffleAsync();
        Card DealCard();
        int CardsLeft();
        Task InitializeDeckAsync(int numberOfDeck);
    }
}