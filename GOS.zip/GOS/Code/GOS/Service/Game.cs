﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Threading;
using System.Threading.Tasks;

namespace GOS
{
    public class Game : IGame
    {
        private readonly List<Player> players;
        private readonly Deck mainDeck;
        private readonly List<Card> centralPile;
        private readonly MatchCondition matchCondition;
        private readonly int playDelayMilliseconds;

        public Game(IList<Player> players, IDeck mainDeck, MatchCondition matchCondition)
        {
            this.players = new List<Player>(players);
            this.mainDeck = mainDeck as Deck ?? throw new ArgumentException("mainDeck must be of type Deck");
            this.centralPile = new List<Card>();
            this.matchCondition = matchCondition;

            // Read playDelayMilliseconds from App.config
            var delaySetting = ConfigurationManager.AppSettings["PlayDelayMilliseconds"];
            if (!int.TryParse(delaySetting, out playDelayMilliseconds))
            {
                playDelayMilliseconds = 0; // Default to 0 if not set or invalid
            }
        }

        public async Task StartGameAsync(CancellationToken ct = default)
        {
            mainDeck.Shuffle();
            DealCardsToPlayers();

            int playerCount = players.Count;
            if (playerCount == 0) return;

            int currentPlayerIndex = 0;
            Card previousCard = null;
            bool needDelay = playDelayMilliseconds > 0;

            // Minimize Console I/O in the hot path by using a simple logger delegate (can be Console.WriteLine)
            void Log(string msg) => Console.WriteLine(msg);

            while (playerCount > 1)
            {
                if (ct.IsCancellationRequested) return;

                var currentPlayer = players[currentPlayerIndex];
                var playedCard = currentPlayer.PlayCard();

                if (playedCard is null)
                {
                    Log($"{currentPlayer.Name} is out of cards!");

                    // Remove the player and adjust index safely
                    players.RemoveAt(currentPlayerIndex);
                    playerCount--;

                    if (playerCount == 1)
                    {
                        Log($"{players[0].Name} wins the game!");
                        break;
                    }

                    // If we removed the last player in the list, wrap to index 0
                    if (currentPlayerIndex >= playerCount)
                        currentPlayerIndex = 0;

                    // Reset previousCard so the next player doesn't accidentally "match" a removed player's last card
                    previousCard = null;
                    continue;
                }

                centralPile.Add(playedCard);
                Log($"{currentPlayer.Name} plays: {playedCard}");

                if (needDelay)
                {
                    // Pass the CancellationToken to make the loop cancellable during delay
                    await Task.Delay(playDelayMilliseconds, ct);
                }

                // Compare against the previous visible card; if matched, transfer pile atomically
                if (previousCard != null && IsMatch(playedCard, previousCard, matchCondition))
                {
                    Log("SNAP! A snap has occurred!");

                    // Only attempt transfer if there is something to take
                    if (centralPile.Count > 0)
                    {
                        currentPlayer.AddCards(centralPile);
                        centralPile.Clear(); // clears references in one shot
                    }

                    Log($"{currentPlayer.Name} takes the pile!");
                    // After a SNAP, there's no "previous" to compare against (pile reset)
                    previousCard = null;
                }
                else
                {
                    // Track last played card only when no snap
                    previousCard = playedCard;
                }

                // Next player (manual wrap avoids modulo cost on every turn)
                currentPlayerIndex++;
                if (currentPlayerIndex >= playerCount)
                    currentPlayerIndex = 0;
            }
        }

        private void DealCardsToPlayers()
        {
            while (mainDeck.CardsLeft() > 0)
            {
                foreach (var player in players)
                {
                    if (mainDeck.CardsLeft() > 0)
                        player.AddCards(new List<Card> { mainDeck.DealCard() });
                }
            }
        }

        private static bool IsMatch(Card c1, Card c2, MatchCondition matchCondition)
        {
            switch (matchCondition)
            {
                case MatchCondition.FaceValue:
                    return c1.FaceMatch(c2);
                case MatchCondition.Suit:
                    return c1.SuitMatch(c2);
                case MatchCondition.Both:
                    return c1.FullMatch(c2) || c1.SuitMatch(c2) || c1.FaceMatch(c2);
                default:
                    return false;
            }
        }
    }
}
