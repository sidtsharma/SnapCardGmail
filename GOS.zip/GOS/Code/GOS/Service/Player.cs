﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOS
{
    public class Player : IPlayer
    {
        public string Name { get; set; }
        public List<Card> Hand => handQueue.ToList();
        private readonly Queue<Card> handQueue;

        public Player(string name)
        {
            Name = name;
            handQueue = new Queue<Card>();
        }

        public void AddCards(List<Card> cardsToAdd)
        {
            foreach (var card in cardsToAdd)
                handQueue.Enqueue(card);
        }

        public Card PlayCard()
        {
            return handQueue.Count > 0 ? handQueue.Dequeue() : null;
        }
    }
}
