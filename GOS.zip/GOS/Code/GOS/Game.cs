﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace GOS
{
    public class Game
    {
        private List<Player> players;
        private Deck mainDeck;
        private List<Card> centralPile;
        private int _matchtype;

        public Game(List<string> playerNames, int numberOfDeck = 1, int matchType = 1)
        {
            players = new List<Player>();
            foreach (var name in playerNames)
            {
                players.Add(new Player(name));
            }

            mainDeck = new Deck(numberOfDeck);
            centralPile = new List<Card>();
            _matchtype = matchType;
        }

        public void StartGame()
        {
            mainDeck.Shuffle();
            DealCardsToPlayers();

            int currentPlayerIndex = 0;
            Card previousCard = null;

            while (true)
            {
                Player currentPlayer = players[currentPlayerIndex];

                // Player takes turn
                Card playedCard = currentPlayer.PlayCard();
                if (playedCard == null)
                {
                    Console.WriteLine($"{currentPlayer.Name} is out of cards!");
                    players.Remove(currentPlayer);
                    if (players.Count == 1)
                    {
                        Console.WriteLine($"{players[0].Name} wins the game!");
                        break;
                    }
                    currentPlayerIndex %= players.Count; // Adjust index
                    continue;
                }

                centralPile.Add(playedCard);
                Console.WriteLine($"{currentPlayer.Name} plays: {playedCard}");
                Thread.Sleep(1000); // Wait 1 second for effect


                Enum.TryParse(_matchtype.ToString(), out MatchCondition matchCondition);

                if (previousCard != null && IsMatch(playedCard, previousCard, matchCondition))
                {
                    Console.WriteLine("SNAP! A snap has occurred!");
                    currentPlayer.AddCards(centralPile);
                    centralPile.Clear();
                    Console.WriteLine($"{currentPlayer.Name} takes the pile!");
                }

                previousCard = playedCard;
                currentPlayerIndex = (currentPlayerIndex + 1) % players.Count;
            }            
        }

        private void DealCardsToPlayers()
        {
            while (mainDeck.CardsLeft() > 0)
            {
                foreach (var player in players)
                {
                    if (mainDeck.CardsLeft() > 0)
                    {
                        player.AddCards(new List<Card> { mainDeck.DealCard() });
                    }
                }
            }
        }

        private bool IsMatch(Card c1, Card c2, MatchCondition matchCondition)
        {
            bool isMatch = false;
            switch (matchCondition)
            {
                case MatchCondition.FaceValue:
                    isMatch = c1.FaceMatch(c2);
                    break;
                case MatchCondition.Suit:
                    isMatch = c1.SuitMatch(c2);
                    break;
                case MatchCondition.Both:
                    isMatch = c1.FullMatch(c2) || c1.SuitMatch(c2) || c1.FaceMatch(c2);
                    break;
            }
            return isMatch;
        }
    }


}
