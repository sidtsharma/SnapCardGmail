﻿

namespace GOS
{
    public enum Suit { Spades, Hearts, Diamonds, Clubs }
    public enum Rank { Two = 2, Three, Four, Five, Six, Seven, Eight, Nine, Ten, J, Q, K, A }
    public enum MatchCondition { FaceValue = 1, Suit, Both }
    public class Constants
    {
        
    }
}
