using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace GOS
{
    public class Startup
    {
        private IDeck _deck; 

        private readonly IServiceProvider _serviceProvider;

        public Startup(IServiceProvider serviceProvider)
        {            
            _serviceProvider = serviceProvider;           
        }

        public async Task RunAsync()
        {           
             int prompt = PromptInt("Enter number of packs (N): ", 1, int.MaxValue);

            _deck = ActivatorUtilities.CreateInstance<Deck>(_serviceProvider, prompt);

            await _deck.InitializeDeckAsync(prompt);
            await _deck.ShuffleAsync();
            Console.WriteLine($"Cards left: {_deck.CardsLeft()}");

            int matchType = PromptInt("Select matching condition:\n1. Face value\n2. Suit\n3. Both\nEnter 1, 2 or 3: ", 1, 3);

            var players = new List<Player>();
            for (int i = 1; i <= 2; i++)
            {
                Console.Write($"Please enter player {i} name : ");
                string playerName = Console.ReadLine();
                var player = ActivatorUtilities.CreateInstance<Player>(_serviceProvider, playerName);
                players.Add(player);
            }

            MatchCondition matchCondition = (MatchCondition)matchType;

            var game = ActivatorUtilities.CreateInstance<Game>(
                _serviceProvider,
                players,
                _deck, matchCondition);

            await game.StartGameAsync();
            Console.ReadKey();
        }

        private int PromptInt(string prompt, int min, int max)
        {
            int value;
            while (true)
            {
                Console.Write(prompt);
                if (int.TryParse(Console.ReadLine(), out value) && value >= min && value <= max)
                    break;
                Console.WriteLine($"Please enter a number between {min} and {max}.");
            }
            return value;
        }
    }
}