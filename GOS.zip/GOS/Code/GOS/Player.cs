﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOS
{
    public class Player
    {
        public string Name { get; set; }
        public List<Card> Hand { get; private set; }

        public Player(string name)
        {
            Name = name;
            Hand = new List<Card>();
        }

        public void AddCards(List<Card> cardsToAdd)
        {
            Hand.AddRange(cardsToAdd);
        }

        public Card PlayCard()
        {
            if (Hand.Count > 0)
            {
                Card cardToPlay = Hand[0];
                Hand.RemoveAt(0);
                return cardToPlay;
            }
            return null;
        }

    }
}
