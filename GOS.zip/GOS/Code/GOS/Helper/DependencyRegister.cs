using Microsoft.Extensions.DependencyInjection;
using System;
using System.Threading.Tasks;

namespace GOS
{
    public class DependencyRegister
    {
        private static readonly DependencyRegister _instance = new DependencyRegister();
        private static IServiceProvider _serviceProvider;
        private static readonly object _lock = new object();

        private DependencyRegister() { }

        public static DependencyRegister Instance => _instance;

        public void RegisterServices(IServiceCollection services)
        {
            lock (_lock)
            {
                // Register IDeck as transient, using async factory for Deck
                services.AddSingleton<IDeck, Deck>();

                // Register IPlayer and Player
                services.AddTransient<IPlayer, Player>();

                // Register IGame and Game
                services.AddTransient<IGame, Game>();

                _serviceProvider = services.BuildServiceProvider();
            }
        }

        public T GetService<T>() where T : class
        {
            lock (_lock)
            {
                if (_serviceProvider == null)
                    throw new InvalidOperationException("Services not registered. Call RegisterServices first.");

                return _serviceProvider.GetService<T>();
            }
        }
    }
}